package com.example.onlinebookclub.discussion;

public class DiscussionBoard {
}
