package com.example.onlinebookclub.review;

public class ViewReview {
}
